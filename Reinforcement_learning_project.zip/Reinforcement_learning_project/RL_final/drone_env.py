import numpy as np
import gymnasium as gym
from gymnasium import utils
from gymnasium.envs.mujoco.mujoco_env import MujocoEnv
from gymnasium.spaces import Box
from gymnasium.envs.registration import register
from rich import print

class DroneEnv(MujocoEnv, utils.EzPickle):
    metadata = {
        "render_modes": [
            "human",
            "rgb_array",
            "depth_array",
        ],
        "render_fps": 20, 
    }
	
	# please change the path to your corresponding path location.(use global path not the relative one). 
    def __init__(self, xml_file="/home/legion/Desktop/RL_final/xmls/final.xml", **kwargs): #
        utils.EzPickle.__init__(self, **kwargs)

        # Variables for randomization 
        self.rand_forward_speed = 0.28
        self.rand_sway_amp = 0.0
        self.rand_sway_freq = 0.0
        self.rand_phase = 0.0

        # Initialize buffers and internal state
        self.time_step = 0
        self.xlist_drone = []
        self.ylist_drone = []
        self.zlist_drone = []
        self.xlist_car = []
        self.ylist_car = []
        self.zlist_car = []

        self.action_buffer = np.array([0, 0, 0, 0], dtype=np.float64)
        self.action_buffer_2 = np.array([0, 0, 0, 0], dtype=np.float64)
        self.input_history_buffer = []
        
        self.dist_between_agents = 0
        self.xy_Distance_between_two_agents = 0
        self.rel_desired_heading_vec = np.array([0, 0, 0], dtype=np.float64)
        self.rel_velocity_vec = np.array([0,0,0],dtype=np.float64)
        self.turn_off_flag = 0

        # Collision detection names
        self.car_body_array = ["Landing_box_col"]
        self.drone_body_array = ["Main_body_col_1", "Main_body_col_2", "Main_body_col_3", "Main_body_col_4"]
        self.drone_blade_array = ["FL_blade_col", "FR_blade_col", "BL_blade_col", "BR_blade_col"]

        # Observation space
        # Based on _get_obs: 4 (action) + 1 (pitch) + 3 (heading) + 3 (velocity) = 11 values
        observation_space = Box(low=-np.inf, high=np.inf, shape=(11,), dtype=np.float64)

        # Initialize MuJoCo env
        MujocoEnv.__init__(
            self,
            model_path=xml_file,
            frame_skip=5,
            observation_space=observation_space,
            **kwargs
        )

    @property
    def is_healthy(self):
        # Access state vecto 
        state = self.state_vector()   # state[2] is z distance state[4] is the pitch               
        
        # Check constraints: Height > -1.9, Pitch < 0.8, Distances
        is_healthy = (state[2] > -1.9 and 
                      abs(state[4]) < 0.8 and 
                      self.dist_between_agents < 4.0 and 
                      self.xy_Distance_between_two_agents < 3)

        # Check for blade collision
        for i in range(self.data.ncon):
            contact = self.data.contact[i]
            geom1_name = self.model.geom(contact.geom1).name
            geom2_name = self.model.geom(contact.geom2).name
            
            # Check if Car Box touches Drone Blade
            if geom2_name == self.car_body_array[0]:
                if geom1_name in self.drone_blade_array:
                    #print("[red]Blade Collision!! : RESET[/red]")
                    return False
        
        return is_healthy

    def step(self, action):
        # Turn-off flag logic
        if self.turn_off_flag == 1:
            action = np.array([0, 0, -0.1, 0], dtype=np.float64) # action is vx vy vz and yaw

        # Update buffers
        self.action_buffer_2 = self.action_buffer.copy()
        self.action_buffer = action.copy()
        self.input_history_buffer.append(action)

        # Physics step
        self.do_simulation(action, self.frame_skip)

        # Kinematic override easier for the drone.
        current_qpos = self.data.qpos.copy()
        
        # set x velocity random every time bounded between 0.2 and 0.5 (since drone vel is bounded between [-0.3,0.3])
        car_vel_x = self.rand_forward_speed
        
        # Calculate Y speed using the random amplitude, frequency, and phase
        car_vel_y = self.rand_sway_amp * np.sin((self.time_step * self.rand_sway_freq) + self.rand_phase)

        # Construct qvel vector
        current_qvel = np.array([
            action[0], action[1], action[2], 0, action[3], 
            0, 0, 0, 0, 0, 
            car_vel_x,  
            car_vel_y,   
            0, 0, 0, 0, 0, 0, 0, 0, 0
        ])
        
        self.set_state(current_qpos, current_qvel)

        # Extract state info
        state = self.state_vector()
        x_drone, y_drone, z_drone = state[0] - 1.5, state[1], state[2] + 2 # offset since see xml files. 
        x_car, y_car, z_car = state[10] - 0.03, state[11], state[12] + 0.1
        
        drone_pos = np.array([x_drone, y_drone, z_drone])
        car_pos = np.array([x_car, y_car, z_car])
        
        # Angles
        roll_ang = state[3]
        pitch_ang = state[4]
        yaw_ang = state[5]

        # Calculate relative heading
        desired_heading_vec = car_pos - drone_pos
        self.dist_between_agents = np.linalg.norm(desired_heading_vec)

        # Rotation matrices
        rot_yaw = np.array([[np.cos(yaw_ang), -np.sin(yaw_ang), 0],
                            [np.sin(yaw_ang), np.cos(yaw_ang), 0],
                            [0, 0, 1]])
        rot_pitch = np.array([[np.cos(pitch_ang), 0, np.sin(pitch_ang)],
                              [0, 1, 0],
                              [-np.sin(pitch_ang), 0, np.cos(pitch_ang)]])
        rot_roll = np.array([[1, 0, 0],
                             [0, np.cos(roll_ang), -np.sin(roll_ang)],
                             [0, np.sin(roll_ang), np.cos(roll_ang)]])

        self.rel_desired_heading_vec = rot_yaw.T @ rot_pitch.T @ rot_roll.T @ desired_heading_vec
        
        # === Relative SPEED === 
        drone_global_vel = np.array([action[0], action[1], action[2]])
        car_global_vel = np.array([car_vel_x, car_vel_y, 0])

        # Calculate difference and rotate into drone body frame
        global_vel_diff = car_global_vel - drone_global_vel
        self.rel_velocity_vec = rot_yaw.T @ rot_pitch.T @ rot_roll.T @ global_vel_diff

        
        # Calculate Rewards
        self.xy_Distance_between_two_agents = np.linalg.norm(drone_pos[0:2] - car_pos[0:2])
        z_dist = np.linalg.norm(drone_pos[2] - car_pos[2])
        
        # Distance reward
        dist_reward = 10 - (6 * self.xy_Distance_between_two_agents + 20 * abs(pitch_ang))

        # Land reward
        land_reward = 0
        if self.xy_Distance_between_two_agents < 0.35:
            land_reward = 30 / (0.1 + z_dist)

        # Goal and collision logic
        goal_reward = 0
        col_reward = 0
        touched_landing_points = set()
        
        for i in range(self.data.ncon):
            contact = self.data.contact[i]
            geom1_name = self.model.geom(contact.geom1).name
            geom2_name = self.model.geom(contact.geom2).name
            
            if geom2_name == self.car_body_array[0]:
                if geom1_name in self.drone_body_array:
                    touched_landing_points.add(geom1_name)
                if geom1_name in self.drone_blade_array:
                    col_reward = -100 
                    print("[red]!!Blade Collision!![/red]")

        if len(touched_landing_points) == 4:
            goal_reward = 500000
            self.turn_off_flag = 1
            print("[green]!!!!!!! SUCCESS !!!!!!![/green]")

        # Smoothness
        over_reward = - 0.2 * np.linalg.norm(np.array(self.action_buffer_2) - np.array(self.action_buffer))
        
        # Tried to add height penalty and time penalty for SAC Algorithm (did not improve results).
        # === Height penalty  === 
        #height_penalty = -z_dist

        # === Time penalty ===
        #time_penalty = 0.1

        # === Total reward === 
        reward = (dist_reward + land_reward + 
                  goal_reward + col_reward + over_reward) 

        # Recording history
        self.xlist_drone.append(x_drone)
        self.ylist_drone.append(y_drone)
        self.zlist_drone.append(z_drone)
        self.xlist_car.append(x_car)
        self.ylist_car.append(y_car)
        self.zlist_car.append(z_car)
        self.time_step += 1

        # Terminated condition
        terminated = not self.is_healthy or (self.turn_off_flag == 1)
        truncated = False 

        obs = self._get_obs()
        info = {'total_reward': reward}

        return obs, reward, terminated, truncated, info
    
    def _get_obs(self):
        # Observation: Action (4) + Pitch (1) + Relative Vec (3) + relative velocity (3) = 11 values
        pitch = self.state_vector()[4]
        return np.concatenate([self.action_buffer, [pitch], self.rel_desired_heading_vec, self.rel_velocity_vec])

    def reset_model(self):
        
        # forward speed
        self.rand_forward_speed = np.random.uniform(0.25, 0.29)
        
        # Sway Width : 0.0 straight to 0.5 zigzag
        self.rand_sway_amp = np.random.uniform(0.0, 0.5)
        
        # Sway Speed : 0.01 gentle to 0.05 aggressive
        self.rand_sway_freq = np.random.uniform(0.01, 0.05)
        
        # Phase shift
        self.rand_phase = np.random.uniform(0, 2 * np.pi)

        # Straight line: 20% chance to a perfect straight line
        if np.random.rand() < 0.2:
            self.rand_sway_amp = 0.0 
        
        # Reset physics
        qpos = self.init_qpos
        qvel = self.init_qvel
        self.set_state(qpos, qvel)

        # Reset internal variables
        self.time_step = 0
        self.xlist_drone = []
        self.ylist_drone = []
        self.zlist_drone = []
        self.xlist_car = []
        self.ylist_car = []
        self.zlist_car = []
        self.action_buffer = np.array([0, 0, 0, 0], dtype=np.float64)
        self.action_buffer_2 = np.array([0, 0, 0, 0], dtype=np.float64)
        self.turn_off_flag = 0
        self.input_history_buffer = []

        return self._get_obs()

# Register the environment for gymnasium
register(
    id="Drone-v1",
    entry_point="drone_env:DroneEnv", 
    max_episode_steps=265,
)
