import os
import gymnasium as gym
import torch
from stable_baselines3 import PPO, SAC
from stable_baselines3.common.env_util import make_vec_env
from stable_baselines3.common.vec_env import SubprocVecEnv, VecMonitor, VecNormalize
from stable_baselines3.common.callbacks import CheckpointCallback, BaseCallback
from typing import Callable
import drone_env 

"""
PPO algorthim since it is on policy, it finds the best path and actually attempt to land.
PPO converges faster reward_ppo = 500_000 upon landing.

On the other hand, SAC reward system depends on exploration and entropy maximzing.
Resetting the env, means no entropy that's why it decides to stay alive for max, farm points,
and gain entropy.  
reward_sac = normal_reward + entropy_reward.
"""

# === Configure ===

# Hardware
NUM_CPU_CORES = 16
DEVICE = "cuda"            

# Training config
TOTAL_TIMESTEPS = 2_000_000  
CHECKPOINT_FREQ = 250_000    

# Paths
BASE_SAVE_DIR = "./comparison_experiment"
LOG_DIR = "./comparison_tb_logs"

# === Helper Functions ===

def lin_schedule(initial_value: float, final_value: float) -> Callable[[float], float]:
    """Linear learning rate schedule."""
    def func(progress_remaining: float) -> float:
        return progress_remaining * (initial_value - final_value) + final_value
    return func

class SaveVecNormalizeCallback(BaseCallback):
    def __init__(self, save_freq: int, save_path: str, name_prefix: str, verbose=0):
        super(SaveVecNormalizeCallback, self).__init__(verbose)
        self.save_freq = save_freq
        self.save_path = save_path
        self.name_prefix = name_prefix

    def _on_step(self) -> bool:
        if self.n_calls % self.save_freq == 0:
            if self.model.get_env() is not None:
                env = self.model.get_env()
                if hasattr(env, 'venv') and isinstance(env.venv, VecNormalize): # type: ignore
                     save_file = os.path.join(self.save_path, f"{self.name_prefix}_vecnorm_{self.num_timesteps}.pkl")
                     env.venv.save(save_file) # type: ignore
                elif isinstance(env, VecNormalize):
                     save_file = os.path.join(self.save_path, f"{self.name_prefix}_vecnorm_{self.num_timesteps}.pkl")
                     env.save(save_file)
        return True                


def create_env(n_envs):
    env = make_vec_env(
        "Drone", 
        n_envs=n_envs, 
        vec_env_cls=SubprocVecEnv
    )
    env = VecMonitor(env, filename=LOG_DIR)
    env = VecNormalize(env, norm_obs=True, norm_reward=True, clip_obs=10., gamma=0.99)
    return env

# Train

def train_ppo():
    algo_name = "PPO"
    save_dir = os.path.join(BASE_SAVE_DIR, algo_name)
    os.makedirs(save_dir, exist_ok=True)
    
    print(f"\n{'='*40}")
    print(f"STARTING {algo_name} TRAINING ({TOTAL_TIMESTEPS} steps)")
    print(f"{'='*40}")

    # Create env
    env = create_env(NUM_CPU_CORES)

    # Callbacks
    checkpoint_cb = CheckpointCallback(
        save_freq=max(CHECKPOINT_FREQ // NUM_CPU_CORES, 1), 
        save_path=save_dir,
        name_prefix=f'{algo_name}_model'
    )
    vecnorm_cb = SaveVecNormalizeCallback(
        save_freq=max(CHECKPOINT_FREQ // NUM_CPU_CORES, 1),
        save_path=save_dir,
        name_prefix=algo_name
    )

    # Initialize model
    policy_kwargs = dict(log_std_init=-2)
    model = PPO(
        "MlpPolicy", 
        env=env, 
        device=DEVICE, 
        verbose=1, 
        tensorboard_log=LOG_DIR,
        learning_rate=lin_schedule(3e-4, 3e-6), # reduce learning rate over time 
        clip_range=lin_schedule(0.3, 0.1), # reduce entropy changing over time(policy dont change too much)
        n_epochs=10, 
        ent_coef=1e-4, #  exploration ? explotation 
        batch_size=2048,
        n_steps=256, # 256 * 16 divided into mini batch of 2048
        policy_kwargs=policy_kwargs # add noise to push the drone to learn 
    )

    # Train
    model.learn(
        total_timesteps=TOTAL_TIMESTEPS, 
        callback=[checkpoint_cb, vecnorm_cb], 
        tb_log_name=f"{algo_name}_Run"
    )

    # Save
    final_path = os.path.join(save_dir, f"{algo_name}_final")
    model.save(final_path)
    env.save(os.path.join(save_dir, f"{algo_name}_vecnorm_final.pkl"))
    
    print(f"DONE {algo_name}. Saved to {save_dir}")
    env.close()
    del model
    del env


def train_sac():
    algo_name = "SAC"
    save_dir = os.path.join(BASE_SAVE_DIR, algo_name)
    os.makedirs(save_dir, exist_ok=True)
    
    print(f"\n{'='*40}")
    print(f"STARTING {algo_name} TRAINING ({TOTAL_TIMESTEPS} steps)")
    print(f"{'='*40}")

    # Create env     
    env = create_env(NUM_CPU_CORES)

    # Callbacks
    checkpoint_cb = CheckpointCallback(
        save_freq=max(CHECKPOINT_FREQ // NUM_CPU_CORES, 1), 
        save_path=save_dir,
        name_prefix=f'{algo_name}_model'
    )
    vecnorm_cb = SaveVecNormalizeCallback(
        save_freq=max(CHECKPOINT_FREQ // NUM_CPU_CORES, 1),
        save_path=save_dir,
        name_prefix=algo_name
    )

    # Initialize Model
    model = SAC(
        "MlpPolicy", 
        env=env, 
        device=DEVICE, 
        verbose=1, 
        tensorboard_log=LOG_DIR,
        buffer_size=1_000_000, 
        learning_rate=3e-4,
        batch_size=256,
        ent_coef='auto',       
        train_freq=1,
        gradient_steps=1
        )

    # Train
    model.learn(
        total_timesteps=TOTAL_TIMESTEPS, 
        callback=[checkpoint_cb, vecnorm_cb], 
        tb_log_name=f"{algo_name}_Run"
    )

    # Save
    final_path = os.path.join(save_dir, f"{algo_name}_final")
    model.save(final_path)
    env.save(os.path.join(save_dir, f"{algo_name}_vecnorm_final.pkl"))
    
    print(f"DONE {algo_name}. Saved to {save_dir}")
    env.close()
    del model
    del env

if __name__ == "__main__":
    os.makedirs(BASE_SAVE_DIR, exist_ok=True)
    os.makedirs(LOG_DIR, exist_ok=True)

    print(f"--- LAUNCHING COMPARISON ON {DEVICE} WITH {NUM_CPU_CORES} CORES ---")
    
    # 1. Run PPO
    try:
        train_ppo()
    except Exception as e:
        print(f"PPO Failed: {e}")

    # 2. Run SAC
    try:
        train_sac()
    except Exception as e:
        print(f"SAC Failed: {e}")

    print("\n--- COMPARISON COMPLETE ---")
    print(f"View results by running: tensorboard --logdir {LOG_DIR}")