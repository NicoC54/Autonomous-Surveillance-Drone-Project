To run use: uv run visualize.py
Happy Reading!

NOTE: uv must be installed (pip install uv).