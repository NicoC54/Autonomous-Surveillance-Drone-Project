import gymnasium as gym
from stable_baselines3 import PPO,SAC
from stable_baselines3.common.vec_env import DummyVecEnv, VecNormalize
import os
import time
import numpy as np
from drone_env import DroneEnv

# "comparison_experiment/PPO/PPO_final.zip"
# "comparison_experiment/PPO/PPO_vecnorm_final.pkl"
# "comparison_experiment/SAC/SAC_vecnorm_1500000.pkl"
# "comparison_experiment/SAC/SAC_model_1500000_steps.zip"

while True:
    visualise = input("Please choose an algorithm (PPO, SAC): ")
    if visualise.lower() in ["ppo","sac"]:
        break
    print("Please choose between PPO and SAC")

if visualise.lower() == "ppo":
    MODEL_PATH = "comparison_experiment/PPO/PPO_final.zip"
    STATS_PATH = "comparison_experiment/PPO/PPO_vecnorm_final.pkl"
elif visualise.lower() == "sac":
    MODEL_PATH = "comparison_experiment/SAC/SAC_model_1500000_steps.zip"
    STATS_PATH = "comparison_experiment/SAC/SAC_vecnorm_1500000.pkl"



"""
When using normalising, if there is a sucess, the env resets directly after sucess, i want to see the sucess for 5 seconds.
The class TestDroneEnv is used to step and launch a counter to wait for 5 seconds.
"""

class TestDroneEnv(DroneEnv):
   
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.success_timer = 0
        self.hold_duration = 60  # hold for 3 seconds

    def step(self, action):
        # Run the step.
        obs, reward, terminated, truncated, info = super().step(action)
        
        # If success
        if self.turn_off_flag == 1:
         
            
            if self.success_timer < self.hold_duration:
                terminated = False 
                self.success_timer += 1
                
            else:
                # Time is up, reset
                terminated = True
                self.success_timer = 0 # reset counter 
        
        return obs, reward, terminated, truncated, info



# === Visualize, Visualize, Visualize === 
def main():
    print(f"--- Loading Model from: {MODEL_PATH} ---")
    
    if not os.path.exists(f"{MODEL_PATH}"):
        print(f"Error: Model not found at {MODEL_PATH}")
        return
    if not os.path.exists(STATS_PATH):
        print("Error: Normalization stats not found.")
        return

    # Create the env
    env = DummyVecEnv([lambda: TestDroneEnv(render_mode="human")])

    # Load the normalization statistics
    env = VecNormalize.load(STATS_PATH, env)
    env.training = False
    env.norm_reward = False

    # Load
    if visualise == "ppo":
        model = PPO.load(MODEL_PATH)
    elif visualise == "sac":
        model = SAC.load(MODEL_PATH)


    
    print("\n--- Starting Simulation ---")    
    try:
        obs = env.reset()
        
        while True:
            # Predict action
            action, _states = model.predict(obs, deterministic=True) # pyright: ignore[reportArgumentType]
            
            # Step in the env
            obs, reward, dones, info = env.step(action)
            
            env.render()
            time.sleep(1.0 / 60.0) 

            if dones[0]:
                #get final reward 
                final_reward = info[0].get('total_reward', 'N/A')
                print(f"Episode Finished. Final Reward: {final_reward}")
                time.sleep(1.0) 

    except KeyboardInterrupt:
        print("\n--- Simulation Stopped by User ---")
    finally:
        env.close()
        print("Environment Closed.")

main()

