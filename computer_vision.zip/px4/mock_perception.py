import numpy as np
import cv2
import math
import time

class MockVisionSystem:
    def __init__(self):
        print("[MockVision] Started in SIMULATION MODE.")
        print("[MockVision] Generating fake target data...")
        self.start_time = time.time()

    def get_target_data(self):
        """
        Simulates a person moving in a pattern:
        1. Moves Left/Right (Yaw test)
        2. Moves Near/Far (Velocity test)
        """
        # Create a black empty image for visualization
        img = np.zeros((480, 640, 3), dtype=np.uint8)
        
        # Calculate fake movement using Sine waves (oscillates back and forth)
        elapsed = time.time() - self.start_time
        
        # Fake Yaw: Target moves left and right every 10 seconds
        # dx ranges from -150 to +150 pixels
        dx = int(math.sin(elapsed * 0.5) * 150)
        
        # Fake Distance: Target walks between 1.5m and 3.5m
        # (Target distance is usually 2.0m, so drone should move forward/back)
        depth_m = 2.5 + math.sin(elapsed * 0.5) 

        found = True

        # Draw the "Fake Person" on the black image so you can see what the drone "thinks" it sees
        cx = 320 + dx
        cv2.circle(img, (cx, 240), 10, (0, 255, 0), -1)
        cv2.putText(img, "SIMULATED PERSON", (cx - 50, 220), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 1)
        
        return found, dx, depth_m, img

    def stop(self):
        print("[MockVision] Stopping simulation.")