import time
import sys
import cv2

# --- CUSTOM MODULES ---
import perception  # The new VisionSystem class you created
import control     # The PID Control logic
import drone       # The DroneKit wrapper

# --- CONFIGURATION ---
CONNECTION_STRING = '/dev/ttyACM0'  # Use '127.0.0.1:14550' for SITL simulation
TARGET_DISTANCE   = 2.0             # Meters (Distance to maintain from person)
FLIGHT_ALTITUDE   = 3             # Meters
SEARCH_YAW_SPEED  = 150             # Fake error value to trigger spin (approx 3 deg/sec)

def main():
    # ---------------------------------------------------------
    # 1. INITIALIZATION
    # ---------------------------------------------------------
    print("[Main] Initializing Computer Vision...")
    vision = perception.VisionSystem()
    
    print(f"[Main] Connecting to Flight Controller at {CONNECTION_STRING}...")
    control.connect_drone(CONNECTION_STRING) #
    
    print("[Main] Configuring PID Controllers...")
    control.configure_PID('PID')             #
    control.set_flight_altitude(FLIGHT_ALTITUDE)

    # ---------------------------------------------------------
    # 2. TAKEOFF SEQUENCE
    # ---------------------------------------------------------
    # The script will pause here until the drone reaches altitude
    print(f"[Main] Arming and Taking Off to {FLIGHT_ALTITUDE}m...")
    control.arm_and_takeoff(FLIGHT_ALTITUDE) #
    print("[Main] Takeoff Complete. Switching to TRACKING mode.")

    # ---------------------------------------------------------
    # 3. MAIN AUTONOMOUS LOOP
    # ---------------------------------------------------------
    try:
        while True:
            # --- SAFETY CHECK: MANUAL OVERRIDE ---
            # Check if pilot switched to LOITER, STABILIZE, or ALT_HOLD
            current_mode = drone.get_mode()
            
            if current_mode != "GUIDED":
                print(f"[Main] Manual Control Detected ({current_mode}). Pausing Autonomy...")
                control.stop_drone() # Stop sending velocity commands
                
                # Wait loop: Do nothing until pilot gives control back
                while drone.get_mode() != "GUIDED":
                    # Keep vision alive so we see what's happening
                    _, _, _, img = vision.get_target_data()
                    cv2.putText(img, f"MANUAL MODE: {current_mode}", (10, 30), 
                                cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 0, 255), 2)
                    cv2.imshow("Drone Vision", img)
                    cv2.waitKey(1)
                    time.sleep(0.5)
                    
                print("[Main] GUIDED mode restored. Resuming Tracking...")

            # --- PERCEPTION PHASE ---
            # found(bool), dx(pixels), current_depth(meters), img(frame)
            found, dx, current_depth, img = vision.get_target_data()

            # --- DECISION PHASE ---
            if found:
                # === TARGET FOUND: TRACKING ===
                
                # 1. Yaw Error (Pixels)
                # If target is Right (Positive dx), we want to turn Right.
                yaw_error = dx 
                
                # 2. Velocity/Distance Error (Meters)
                # If 3.0m away (Target 2.0m) -> Error +1.0 -> Move Forward
                dist_error = current_depth - TARGET_DISTANCE

                # Noise Filter: If depth is weirdly close (<0.5m), ignore it to prevent crash
                if current_depth < 0.5:
                    dist_error = 0

                # 3. Update Controllers
                control.setXdelta(yaw_error)  # Sets input for Yaw PID
                control.setZDelta(dist_error) # Sets input for Velocity PID
                
                # 4. Execute Movement
                control.control_drone()       # Calculates and sends MAVLink commands

                # Status Overlay
                status_msg = f"TRACKING | Dist: {current_depth:.2f}m | Err: {dist_error:.2f}"
                cv2.putText(img, status_msg, (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 0), 2)

            else:
                # === TARGET LOST: SEARCHING ===
                
                # 1. Stop Flying Forward/Back (Safety)
                control.setZDelta(0)
                
                # 2. Command a Slow Spin
                # We feed a constant "error" so the PID keeps turning the drone
                control.setXdelta(SEARCH_YAW_SPEED) 
                
                # 3. Execute
                control.control_drone()
                
                # Status Overlay
                status_msg = "SEARCHING (Spinning)..."
                cv2.putText(img, status_msg, (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 255), 2)

            # --- VISUALIZATION ---
            if img is not None:
                cv2.imshow("Drone Vision", img)
                # Allow manual exit with 'q' key
                if cv2.waitKey(1) & 0xFF == ord('q'):
                    print("[Main] User requested landing via Keyboard.")
                    break
            
            # Control Loop Frequency (approx 20-30Hz)
            time.sleep(0.01)

    except KeyboardInterrupt:
        print("\n[Main] Keyboard Interrupt Detected!")

    except Exception as e:
        print(f"\n[Main] Critical Error: {e}")

    finally:
        # ---------------------------------------------------------
        # 4. SHUTDOWN SEQUENCE
        # ---------------------------------------------------------
        print("[Main] Landing Vehicle...")
        control.land() #
        
        print("[Main] Stopping Vision System...")
        vision.stop()
        cv2.destroyAllWindows()
        print("[Main] System Shutdown.")

if __name__ == "__main__":
    main()
