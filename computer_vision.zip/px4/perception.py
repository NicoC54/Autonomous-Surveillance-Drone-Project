import cv2
import numpy as np
import pyrealsense2 as rs
from ultralytics import YOLO # type: ignore

class VisionSystem:
    def __init__(self):
        # ---------- Config ----------
        self.YOLO_MODEL_PATH = "yolo11n.engine"
        self.PERSON_CLASS_ID = 0          # COCO: 0 = person
        self.CONF_THRESHOLD = 0.65

        print("[Vision] Initializing RealSense...")
        # ---------- Init RealSense ----------
        self.pipeline = rs.pipeline() # type: ignore
        config = rs.config()# type: ignore
        config.enable_stream(rs.stream.depth, 640, 480, rs.format.z16, 30)# type: ignore
        config.enable_stream(rs.stream.color, 640, 480, rs.format.bgr8, 30)# type: ignore
        self.profile = self.pipeline.start(config)

        # Align depth to color
        align_to = rs.stream.color# type: ignore
        self.align = rs.align(align_to)# type: ignore

        # ---------- Init YOLO11 ----------
        print("[Vision] Loading YOLO Model...")
        self.model = YOLO(self.YOLO_MODEL_PATH)
        print("[Vision] System Ready.")

    def get_target_data(self):
        """
        Captures a frame, runs detection, and returns target info.
        Returns: 
            found (bool): True if a person is seen
            dx (int): Horizontal error in pixels (Positive = Right, Negative = Left)
            depth_m (float): Distance to target in meters
            image (numpy array): The annotated image for debugging
        """
        
        # 1) Get frames and align
        frames = self.pipeline.wait_for_frames()
        aligned_frames = self.align.process(frames)

        depth_frame = aligned_frames.get_depth_frame()
        color_frame = aligned_frames.get_color_frame()

        if not depth_frame or not color_frame:
            return False, 0, 0.0, None

        # 2) Convert to numpy (BGR for OpenCV)
        color_image = np.asanyarray(color_frame.get_data())
        h, w, _ = color_image.shape
        cx_img, cy_img = w // 2, h // 2

        # 3) Run YOLO11
        results = self.model(color_image, verbose=False)[0]

        target_found = False
        dx = 0
        depth_m = 0.0

        # 4) Process detections
        for box in results.boxes:
            cls_id = int(box.cls[0].item())
            conf = float(box.conf[0].item())

            # Filter by confidence and class
            if conf < self.CONF_THRESHOLD or cls_id != self.PERSON_CLASS_ID:
                continue

            # ---- TARGET FOUND ----
            target_found = True

            # box.xyxy format: [x1, y1, x2, y2]
            x1, y1, x2, y2 = box.xyxy[0].cpu().numpy().astype(int)

            # Center of detection box
            cx_box = (x1 + x2) // 2
            cy_box = (y1 + y2) // 2

            # Pixel distance (Error for Yaw PID)
            dx = cx_box - cx_img  
            
            # Depth at bbox center (Error for Velocity PID)
            depth_m = depth_frame.get_distance(cx_box, cy_box)

            # Drawing for Debug
            cv2.rectangle(color_image, (x1, y1), (x2, y2), (0, 255, 0), 2)
            cv2.circle(color_image, (cx_box, cy_box), 5, (0, 0, 255), -1)
            cv2.line(color_image, (cx_img, cy_img), (cx_box, cy_box), (255, 255, 0), 2)
            
            label = f"Dist: {depth_m:.2f}m | dx: {dx}"
            cv2.putText(color_image, label, (x1, max(y1 - 10, 0)),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 255), 2)

            # Stop after the first valid person (Single Target Tracking)
            break

        return target_found, dx, depth_m, color_image

    def stop(self):
        print("[Vision] Stopping RealSense pipeline")
        self.pipeline.stop()

# --- Small test block to run this file standalone ---
if __name__ == "__main__":
    vision = VisionSystem()
    try:
        while True:
            found, dx, dist, img = vision.get_target_data()
            if img is not None:
                cv2.imshow("Perception Test", img)
            if cv2.waitKey(1) == 27:
                break
    finally:
        vision.stop()
        cv2.destroyAllWindows()
